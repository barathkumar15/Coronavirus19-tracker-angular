export interface DataWiseData
{
            countryCode?: string,
            slug?: string,
            newConfirmed?: number,
            totalConfirmed?: number,
            newDeaths?: number,
            totalDeaths?: number,
            newRecovered?: number,
            totalRecovered?: number,
            Date?: Date,
            Country:number,
            Active:number,
            Recovered:number,
            Deaths:number,
            Confirmed:number

          }
